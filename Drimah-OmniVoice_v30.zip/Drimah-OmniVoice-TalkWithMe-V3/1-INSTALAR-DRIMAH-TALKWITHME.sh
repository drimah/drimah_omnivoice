#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "=========================================="
echo "Drimah OmniVoice - REST local"
echo "=========================================="
if [ ! -x ".venv/bin/python" ]; then
  echo "Criando ambiente Python..."
  python3 -m venv .venv
fi
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r backend/requirements.txt
echo
echo "Instalação concluída."
echo "Use 2-INICIAR-DRIMAH-TALKWITHME.sh para iniciar."
