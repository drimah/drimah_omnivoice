#!/usr/bin/env bash
cd "$(dirname "$0")"
source .venv/bin/activate
echo "=========================================="
echo "Drimah OmniVoice REST local"
echo "http://127.0.0.1:8181/ui"
echo "Mantenha esta janela aberta."
echo "=========================================="
python backend/server.py
