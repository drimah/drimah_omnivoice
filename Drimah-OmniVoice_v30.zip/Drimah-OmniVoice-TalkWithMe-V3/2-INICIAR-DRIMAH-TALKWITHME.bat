@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
call ".venv\Scripts\activate.bat"

rem Escolhe automaticamente uma porta livre, evitando o erro Windows 10048.
set "PORT=8181"
:CHECK_PORT
powershell -NoProfile -Command "$p=Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue; if($p){exit 1}else{exit 0}" >nul 2>&1
if not errorlevel 1 goto PORT_OK
set /a PORT+=1
goto CHECK_PORT

:PORT_OK
set "DRIMAH_PORT=%PORT%"
echo ==========================================
echo Drimah OmniVoice REST local
echo http://127.0.0.1:%PORT%/ui
echo Porta selecionada automaticamente: %PORT%
echo Mantenha esta janela aberta.
echo ==========================================
start "Drimah OmniVoice" "http://127.0.0.1:%PORT%/ui"
python backend\server.py
pause
