from __future__ import annotations
import base64, io, math, os, random, time, uuid, tempfile, hashlib
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import soundfile as sf
import torch
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel, Field, field_validator
from typing_extensions import Literal
from loguru import logger
from omnivoice import OmniVoice, OmniVoiceGenerationConfig, VoiceClonePrompt

MODEL_NAME_OR_PATH = os.environ.get("OMNIVOICE_MODEL", "k2-fsa/OmniVoice")
DEFAULT_GUIDANCE_SCALE = 1.2
SEED_MIN, SEED_MAX = 1, 1000
NUM_STEPS_MIN, NUM_STEPS_MAX = 10, 20

@dataclass
class OmniVoiceRuntime:
    model: OmniVoice
    sample_rate: int

_runtime = None
VOICE_CACHE = Path(__file__).resolve().parents[1] / "voices_cache"
VOICE_CACHE.mkdir(parents=True, exist_ok=True)
progress = {"percent": 0, "message": "Iniciando…", "busy": False, "indeterminate": False}

def set_progress(percent, message, indeterminate=False):
    progress.update(percent=int(percent), message=message, indeterminate=bool(indeterminate))

def choose_device():
    return "cuda" if torch.cuda.is_available() else "cpu"

def load_model():
    global _runtime
    if _runtime is not None:
        return _runtime
    device = choose_device()
    set_progress(5, "Carregando OmniVoice…")
    if device == "cuda":
        model = OmniVoice.from_pretrained(MODEL_NAME_OR_PATH, device_map="cuda", torch_dtype=torch.float16)
    else:
        model = OmniVoice.from_pretrained(MODEL_NAME_OR_PATH, device_map="cpu", torch_dtype=torch.float32)
    _runtime = OmniVoiceRuntime(model=model, sample_rate=model.sampling_rate)
    set_progress(100, "OmniVoice local pronto.")
    logger.info("OmniVoice pronto — dispositivo: {}", device)
    return _runtime

class SynthesisRequest(BaseModel):
    text: str
    audio_base64: str
    prompt_text: str | None = None
    voice_id: str | None = None
    seed: int | None = Field(None, ge=SEED_MIN, le=SEED_MAX)
    num_steps: int | None = Field(None, ge=NUM_STEPS_MIN, le=NUM_STEPS_MAX)
    guidance_scale: float = DEFAULT_GUIDANCE_SCALE
    speaker_scale: float = 1.5
    ode_method: Literal["euler","midpoint","rk4"] = "euler"
    language: str | None = None

def _audio_bytes(audio_base64: str) -> bytes:
    try:
        return base64.b64decode(audio_base64)
    except Exception as exc:
        raise HTTPException(400, f"Áudio inválido: {exc}")

def _voice_id(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()

def _prompt_path(voice_id: str) -> Path:
    if not voice_id or len(voice_id) != 64 or any(c not in "0123456789abcdef" for c in voice_id.lower()):
        raise HTTPException(400, "Identificador de voz inválido.")
    return VOICE_CACHE / f"{voice_id}.pt"

def _prepare_prompt(raw: bytes, voice_id: str):
    path = _prompt_path(voice_id)
    if path.exists():
        set_progress(25, "Voz salva encontrada — sem nova transcrição.")
        return VoiceClonePrompt.load(str(path))
    fd, wav_path = tempfile.mkstemp(prefix="drimah_ref_", suffix=".wav")
    os.close(fd)
    Path(wav_path).write_bytes(raw)
    try:
        rt = load_model()
        set_progress(12, "Preparando sua voz pela primeira vez…")
        set_progress(18, "Transcrição automática da referência — somente esta vez…")
        prompt = rt.model.create_voice_clone_prompt(ref_audio=wav_path, ref_text=None, preprocess_prompt=True)
        prompt.save(str(path))
        set_progress(32, "Voz preparada e salva. Nas próximas vezes não haverá transcrição.")
        return prompt
    finally:
        try: Path(wav_path).unlink(missing_ok=True)
        except OSError: pass

app=FastAPI(title="Drimah OmniVoice REST")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False, allow_methods=["*"], allow_headers=["*"])

@app.post("/prepare_voice")
def prepare_voice(payload: dict):
    progress["busy"] = True
    try:
        raw = _audio_bytes(payload.get("audio_base64", ""))
        vid = _voice_id(raw)
        _prepare_prompt(raw, vid)
        set_progress(100, "Voz preparada e salva localmente.")
        return {"ok": True, "voice_id": vid, "message": "Voz preparada e salva localmente."}
    except Exception:
        set_progress(0, "Falha ao preparar a voz.")
        raise
    finally:
        progress["busy"] = False


class DesignRequest(BaseModel):
    text: str
    instruct: str = ""
    language: str | None = None
    speed: float | None = Field(None, ge=0.5, le=1.5)
    duration: float | None = Field(None, gt=0)
    num_steps: int = Field(32, ge=4, le=64)
    guidance_scale: float = Field(2.0, ge=0, le=4)
    denoise: bool = True
    preprocess_prompt: bool = True
    postprocess_output: bool = True
    seed: int | None = Field(None, ge=SEED_MIN, le=SEED_MAX)

@app.post("/design", response_model=SynthesisResponse)
def design(req: DesignRequest):
    if not req.text.strip():
        raise HTTPException(400, "Texto vazio.")
    if not req.instruct.strip():
        raise HTTPException(400, "Escolha pelo menos um atributo para criar a voz.")
    progress["busy"] = True
    try:
        set_progress(2, "Verificando os atributos da voz…")
        rt = load_model()
        seed = req.seed if req.seed is not None else random.randint(SEED_MIN, SEED_MAX)
        lang = req.language
        if lang and lang.lower() in {"auto", ""}:
            lang = None
        lang_map = {
            "pt":"Portuguese","pt-br":"Portuguese","en":"English","es":"Spanish",
            "fr":"French","de":"German","it":"Italian","ja":"Japanese",
            "ko":"Korean","zh":"Chinese","ru":"Russian"
        }
        if lang:
            lang = lang_map.get(lang.lower(), lang)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)

        cfg = OmniVoiceGenerationConfig(
            num_step=int(req.num_steps),
            guidance_scale=float(req.guidance_scale),
            denoise=bool(req.denoise),
            preprocess_prompt=bool(req.preprocess_prompt),
            postprocess_output=bool(req.postprocess_output),
        )
        set_progress(30, "Criando uma voz a partir da descrição…", indeterminate=True)
        t0 = time.perf_counter()
        kwargs = {
            "text": req.text,
            "instruct": req.instruct.strip(),
            "language": lang,
            "generation_config": cfg,
        }
        if req.speed is not None:
            kwargs["speed"] = float(req.speed)
        if req.duration is not None:
            kwargs["duration"] = float(req.duration)

        with torch.inference_mode():
            audio = rt.model.generate(**kwargs)[0]
        elapsed = time.perf_counter() - t0
        set_progress(90, "Voz criada. Montando o arquivo de áudio…")
        buf = io.BytesIO()
        sf.write(buf, audio, rt.sample_rate, format="WAV", subtype="PCM_16")
        duration_out = len(audio) / rt.sample_rate if rt.sample_rate else 0
        set_progress(100, "Voz criada e áudio pronto.")
        return SynthesisResponse(
            audio_base64=base64.b64encode(buf.getvalue()).decode("ascii"),
            sample_rate=rt.sample_rate,
            seed=seed,
            num_steps=int(req.num_steps),
            fid=str(uuid.uuid4()),
            time_used=elapsed,
            rtf=(elapsed / duration_out if duration_out else None),
        )
    except Exception as exc:
        logger.exception("Voice design failed")
        set_progress(0, "Falha na criação da voz.")
        raise HTTPException(500, str(exc))
    finally:
        progress["busy"] = False

class SynthesisResponse(BaseModel):
    audio_base64: str
    sample_rate: int
    seed: int
    num_steps: int
    fid: str
    time_used: float
    rtf: float | None
    @field_validator("rtf", mode="before")
    @classmethod
    def clean_rtf(cls,v):
        if v is None or (isinstance(v,float) and (math.isnan(v) or math.isinf(v))): return None
        return v

class HealthResponse(BaseModel):
    status: Literal["ok"] = "ok"
    serverType: Literal["OmniVoice"] = "OmniVoice"
    model: str = MODEL_NAME_OR_PATH

@app.get("/", include_in_schema=False)
def root():
    return FileResponse(Path(__file__).resolve().parents[1] / "omnivoice-drimah-talkwithme.html")

@app.get("/health", response_model=HealthResponse)
def health():
    load_model()
    return HealthResponse()

@app.get("/status")
def status():
    ready = _runtime is not None
    dev = torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU"
    return {"ok": True, "ready": ready, "device": ("CUDA: "+dev) if torch.cuda.is_available() else "CPU"}

@app.get("/progress")
def get_progress():
    return dict(progress)

@app.get("/ui", include_in_schema=False)
def ui():
    return FileResponse(Path(__file__).resolve().parents[1] / "omnivoice-drimah-talkwithme.html")

@app.post("/synthesize", response_model=SynthesisResponse)
def synthesize(req: SynthesisRequest):
    if not req.text.strip(): raise HTTPException(400,"Texto vazio.")
    progress["busy"] = True
    try:
        set_progress(2, "Verificando o texto e os parâmetros…")
        rt=load_model()
        seed=req.seed if req.seed is not None else random.randint(SEED_MIN,SEED_MAX)
        steps=req.num_steps if req.num_steps is not None else 16
        raw=_audio_bytes(req.audio_base64)
        vid=req.voice_id or _voice_id(raw)
        set_progress(15, "Localizando a voz de referência…")
        prompt=_prepare_prompt(raw, vid)
        set_progress(35, "Referência pronta. Preparando a síntese…")
        lang=req.language
        if lang and lang.lower() in {"auto",""}: lang=None
        lang_map={"pt":"Portuguese","pt-br":"Portuguese","en":"English","es":"Spanish","fr":"French","de":"German","it":"Italian","ja":"Japanese","ko":"Korean","zh":"Chinese","ru":"Russian"}
        if lang: lang=lang_map.get(lang.lower(),lang)
        torch.manual_seed(seed)
        if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)
        t0=time.perf_counter()
        cfg=OmniVoiceGenerationConfig.from_dict({"num_step":steps,"guidance_scale":req.guidance_scale})
        set_progress(45, "Gerando a voz com o OmniVoice…", indeterminate=True)
        with torch.inference_mode():
            audio=rt.model.generate(text=req.text,voice_clone_prompt=prompt,language=lang,generation_config=cfg)[0]
        elapsed=time.perf_counter()-t0
        set_progress(90, "Síntese concluída. Montando o arquivo de áudio…")
        buf=io.BytesIO(); sf.write(buf,audio,rt.sample_rate,format="WAV",subtype="PCM_16")
        duration=len(audio)/rt.sample_rate if rt.sample_rate else 0
        set_progress(100, "Áudio pronto.")
        return SynthesisResponse(audio_base64=base64.b64encode(buf.getvalue()).decode("ascii"),sample_rate=rt.sample_rate,seed=seed,num_steps=steps,fid=str(uuid.uuid4()),time_used=elapsed,rtf=(elapsed/duration if duration else None))
    except Exception as exc:
        logger.exception("Synthesis failed")
        set_progress(0,"Falha na geração.")
        raise HTTPException(500,str(exc))
    finally:
        progress["busy"] = False

if __name__=="__main__":
    import uvicorn
    uvicorn.run(app,host="127.0.0.1",port=8181)
